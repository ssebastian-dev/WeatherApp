package com.example.weatherdemo.ui.theme

import androidx.compose.ui.graphics.Color

val NeutralVariant10 = Color(0xFF191A20)
val NeutralVariant30 = Color(0xFF60626E)

val Error = Color(0xFFCE0B31)

val Gray = Color(0xFF8E8E93)
val Gray2 = Color(0xFFAEAEB2)
val Gray3 = Color(0xFFC7C7CC)